package uk.ac.ntu.cloudfs.common;

public final class Version {
    private Version() {}

    public static final String NAME = "cloudfs-comp20081";
    public static final String VERSION = "0.1.0";
}