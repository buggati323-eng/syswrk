#CloudFS – COMP20081 Distributed File System

Vilius Vaivada
COMP20081 – Systems Software
Java: 21+
Docker Compose 


#Overview

CloudFS is a distributed file system consisting of:
	Load Balancer (LB) – request routing, scheduling, encryption, ACLs, audit
	Storage Nodes (×4) – chunk storage with artificial delay
	MySQL – users, files, ACLs, audit logs
	SQLite – sessions, cache
	JavaFX Client UI – terminal + admin interface

The system supports file chunking, replication, encryption, access control, scheduling algorithms, artificial delay, and audit logging.

1 - Build everything

mvn clean package
docker compose down -v
docker compose up --build

(This starts MySQL, 4 Nodes, LB on port 8081)

2 - start UI

mvn -pl client-ui javafx:run

#Demo 

User and File operations:
    register user alice and bob. log in as alice
    use terminal:
    touch a.txt
    nano a.txt
    nano.set hello
    nano.save
    cat /a.txt

    share file:
    share /a.txt bob r
    
    log in as bob
    cat /a.txt (success)
    rm /a.txt (fails)

    log in as alice
    share /a.txt bob rw

    Artificial Delay:
    curl localhost:8081/api/ping

    Scheduling Algorithms:
    LB_SCHEDULER=round_robin
    LB_SCHEDULER=least_loaded
    LB_SCHEDULER=random 
    curl localhost:8081/metrics

Terminal commands:
pwd

Prints the current working directory for the logged-in user.
This reflects the user’s location within the virtual file system (VFS).

cd <path>

Changes the current working directory.
Supports absolute and relative paths and validates that the target exists and is a directory.

ls [path]

Lists the contents of a directory.
If no path is provided, it lists the current working directory.

tree [path]

Recursively displays the directory structure starting from the given path (or current directory if omitted).
Useful for visualising the file hierarchy.

mkdir <path>

Creates a new directory at the specified path.
Fails if the parent directory does not exist.

touch <path>

Creates a new empty file at the given path.
If the file already exists, the command does nothing (matching standard UNIX behaviour).

cat <path>

Displays the contents of a file.
Enforces read permissions via ACLs and retrieves the file by reconstructing its stored chunks.

rm <path>

Removes a file or directory.
Directories are removed recursively.
The command enforces write permissions and refuses to remove the root directory.

nano <path>

Opens a simple in-memory text editor for a file.
If the file does not exist, it is created automatically.

Subcommands:
	nano.show – displays the current buffer
	nano.set <text> – replaces the buffer contents
	nano.append <text> – appends text to the buffer
	nano.save – writes the buffer to distributed storage
	nano.exit – closes the editor session

mv <src> <dst>

Moves or renames a file or directory.
For directories, the entire subtree is moved.
The operation updates the VFS only and does not duplicate stored data.

cp <src> <dst>

Copies a file or directory within the VFS.
Files share the same underlying file ID, meaning data is not duplicated in storage.

ps

Displays a simulated process list.
Used to demonstrate system awareness and background components.

whoami

Displays the username of the currently authenticated user.

Admin features:
    view users
    ceate users
    change roles
    view audit log
    curl localhost:8081/api/admin/audit
